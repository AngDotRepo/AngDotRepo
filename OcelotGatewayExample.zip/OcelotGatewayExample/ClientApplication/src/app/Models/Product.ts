export class Product {
    productId: any;
    productName?: string;
    productPrice?: number;
    productDescription?: string;
    productStock?: number;
  }