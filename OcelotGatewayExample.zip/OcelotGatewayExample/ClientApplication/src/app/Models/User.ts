export class User {
    userId: any;
    userName?: string;
    address?: string;
  }